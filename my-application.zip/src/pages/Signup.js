import React from "react";
import SignUpCard from "../components/SignUpCard";

export default function Signup() {
  return (
    <div className="d-flex justify-content-center">
      <SignUpCard />
    </div>
  );
}
