### cmpe277_clapapp
### Course: Smartphone Application Development

### Learning Objective:
using Proximity (TYPE_PROXIMITY) sensor, develop mobile clap app. The goal is to simulate clapping using mobile phone and hand.

### Clap counter ON.
![counter15](screenshots/counter15.jpeg)

### Clap counter OFF and clap count 5seconds.

![clap6](screenshots/clap6.jpeg)

### Clap counter OFF and clap count 10seconds.

![clap11](screenshots/clap11.jpeg)

### Clap counter OFF and clap count 15seconds.
![clap23](screenshots/clap23.jpeg)





