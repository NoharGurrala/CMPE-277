export const LOGIN_NUMBER = "LOGIN_NUMBER";

export const login = (payload) => ({
  type: LOGIN_NUMBER,
  payload,
});
