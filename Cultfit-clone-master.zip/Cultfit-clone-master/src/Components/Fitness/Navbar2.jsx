import React from 'react';
import "./Navbar2.css";

export const Navbar2 = () => {
  return (
     <div className='second-nav'>
           <a className='nav-link'>CultpassELITE</a>
           <a className='nav-link' >CultpassPRO</a>
           <a className='nav-link'>CultpassLIVE</a>
           <a className='nav-link'>CultpassTransform</a>       
     </div>
  )
}
