import React from "react";
import "./Navbarmind.css";

export const Navbarmind = () => {
  return (
    <div className="mind-nav">
      <div className="mind-link-btn">Therapy</div>
      <div className="mind-link">Mindfullness</div>
    </div>
  );
};
