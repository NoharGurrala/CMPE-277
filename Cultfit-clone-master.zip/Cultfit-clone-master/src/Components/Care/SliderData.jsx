export const SliderData = [
  {
    image:
      "https://cdn-images.cure.fit/www-curefit-com/image/upload/fl_progressive,f_auto,q_auto:eco,w_1440,ar_2880:595/dpr_2/image/vm/66b45885-d5d9-430d-89ef-0b03a41853d6.png",
  },
  {
    image:
      "https://cdn-images.cure.fit/www-curefit-com/image/upload/fl_progressive,f_auto,q_auto:eco,w_1440,ar_2880:595/dpr_2/image/vm/e71d8ad0-e0e2-4b2b-ba16-ca2b91b66561.jpg",
  },
  {
    image:
      "https://cdn-images.cure.fit/www-curefit-com/image/upload/fl_progressive,f_auto,q_auto:eco,w_1440,ar_2880:595/dpr_2/image/vm/d1922c97-96e3-4022-90ea-3a200ba229cc.png",
  },
];
