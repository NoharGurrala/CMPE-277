## Project Title : CULTFIT CLONE<br /><br />

#### cult.fit (formerly cure.fit or Curefit) is a health and fitness company offering digital and offline experiences across fitness, nutrition, and mental well-being. <br /><br />

## <b>Getting Started with --</b></br></b></br>

## We are using this tools and technology to clone the website.</b></br></b></br>

# Technologies

<ol>
<li> REACT JS</li>
<li> REDUX </li>
<li> SASS</li>
<li> NODE JS </li>
  <li> MONGO DB </li>
  <li> EXPRESS </li>

</ol>

# Tools

<ol>
<li> VS CODE</li>
<li> GIT</li>
<li> GITHUB</li>
<li> Local Storage</li>
  <li> POSTMAN </li>
</ol>

# Tools for communications

<ol>
<li> SLACK</li>
<li> ZOOM</li>
</ol>

### Before starting the cloning of original website firstly, we tried to understand the features and functionality of the website then we proceed to cloning the website.<br /><br />
