# ChatGPT
Chat GPT (Open AI ) with swift for ios

[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)

[![forthebadge](https://forthebadge.com/images/badges/built-with-swag.svg)](https://forthebadge.com)

<a href='https://ko-fi.com/wycliffn2291' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://az743702.vo.msecnd.net/cdn/kofi2.png?v=0' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>
      
## Video
https://user-images.githubusercontent.com/46722362/215692969-da9a6252-a408-46fb-9ae8-72a768b83872.mp4

https://user-images.githubusercontent.com/46722362/215694177-c47a0e86-63d7-4f20-9db7-8f2087c20344.mp4
